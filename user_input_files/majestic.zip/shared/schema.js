import { pgTable, serial, varchar, text, integer, decimal, boolean, timestamp, date, index, unique, jsonb } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: varchar('email', { length: 255 }).unique(),
  googleId: varchar('google_id', { length: 255 }).unique(),
  name: varchar('name', { length: 255 }),
  avatarUrl: text('avatar_url'),
  // Profile fields
  sex: varchar('sex', { length: 50 }),
  dateOfBirth: date('date_of_birth'),
  heightFeet: integer('height_feet'),
  heightInches: integer('height_inches'),
  heightCm: integer('height_cm'),
  weightLbs: decimal('weight_lbs', { precision: 5, scale: 2 }),
  weightKg: decimal('weight_kg', { precision: 5, scale: 2 }),
  ethnicity: varchar('ethnicity', { length: 100 }),
  countryOfResidence: varchar('country_of_residence', { length: 3 }),
  smoker: boolean('smoker'),
  packsPerWeek: decimal('packs_per_week', { precision: 3, scale: 1 }),
  alcoholDrinksPerWeek: integer('alcohol_drinks_per_week'),
  pregnant: boolean('pregnant'),
  pregnancyStartDate: date('pregnancy_start_date'),
  cyclePhase: varchar('cycle_phase', { length: 50 }),
  profileCompleted: boolean('profile_completed').default(false),
  profileUpdatedAt: timestamp('profile_updated_at'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Health Systems table
export const healthSystems = pgTable('health_systems', {
  id: integer('id').primaryKey(),
  name: varchar('name', { length: 100 }).notNull(),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Uploads table
export const uploads = pgTable('uploads', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }),
  filename: varchar('filename', { length: 255 }).notNull(),
  fileType: varchar('file_type', { length: 50 }),
  fileSize: integer('file_size'),
  uploadType: varchar('upload_type', { length: 50 }).default('manual'),
  storagePath: text('storage_path'),
  processingStatus: varchar('processing_status', { length: 50 }).default('pending'),
  processingError: text('processing_error'),
  createdAt: timestamp('created_at').defaultNow(),
  processedAt: timestamp('processed_at'),
});

// Metrics table
export const metrics = pgTable('metrics', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }),
  uploadId: integer('upload_id').references(() => uploads.id, { onDelete: 'cascade' }),
  systemId: integer('system_id').references(() => healthSystems.id),
  metricName: varchar('metric_name', { length: 255 }).notNull(),
  metricValue: decimal('metric_value'),
  metricUnit: varchar('metric_unit', { length: 50 }),
  referenceRange: text('reference_range'),
  isKeyMetric: boolean('is_key_metric').default(false),
  isOutlier: boolean('is_outlier').default(false),
  testDate: date('test_date'),
  createdAt: timestamp('created_at').defaultNow(),
}, (table) => {
  return {
    uniqueMetric: unique().on(table.userId, table.metricName, table.testDate, table.uploadId),
  };
});

// Questionnaire Responses table
export const questionnaireResponses = pgTable('questionnaire_responses', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }),
  questionType: varchar('question_type', { length: 255 }).notNull(),
  question: text('question').notNull(),
  response: text('response').notNull(),
  responseDate: date('response_date').defaultNow(),
  createdAt: timestamp('created_at').defaultNow(),
});

// AI Outputs Log table
export const aiOutputsLog = pgTable('ai_outputs_log', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }),
  systemId: integer('system_id').references(() => healthSystems.id),
  inputType: varchar('input_type', { length: 50 }),
  inputData: text('input_data'),
  outputType: varchar('output_type', { length: 50 }),
  outputData: text('output_data'),
  processingTime: integer('processing_time'),
  tokensUsed: integer('tokens_used'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Daily Plans table
export const dailyPlans = pgTable('daily_plans', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }),
  planDate: date('plan_date').notNull(),
  planData: text('plan_data'),
  isCompleted: boolean('is_completed').default(false),
  createdAt: timestamp('created_at').defaultNow(),
}, (table) => {
  return {
    uniquePlan: unique().on(table.userId, table.planDate),
  };
});

// Imaging Studies table
export const imagingStudies = pgTable('imaging_studies', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }),
  uploadId: integer('upload_id').references(() => uploads.id, { onDelete: 'cascade' }),  
  linkedSystemId: integer('linked_system_id').references(() => healthSystems.id),
  studyType: varchar('study_type', { length: 100 }),
  fileUrl: text('file_url'),
  thumbnailUrl: text('thumbnail_url'),
  testDate: date('test_date'),
  aiSummary: text('ai_summary'),
  metricsJson: jsonb('metrics_json'),
  comparisonSummary: text('comparison_summary'),
  metricChangesJson: jsonb('metric_changes_json'),
  status: varchar('status', { length: 50 }),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// User Custom Metrics table
export const userCustomMetrics = pgTable('user_custom_metrics', {
  id: serial('id').primaryKey(),
  systemId: integer('system_id').references(() => healthSystems.id).notNull(),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  metricName: text('metric_name').notNull(),
  value: text('value').notNull(),
  units: varchar('units', { length: 255 }).notNull(),
  normalRangeMin: decimal('normal_range_min'),
  normalRangeMax: decimal('normal_range_max'),
  rangeApplicableTo: varchar('range_applicable_to', { length: 255 }).notNull(),
  sourceType: varchar('source_type', { length: 50 }).notNull(),
  reviewStatus: varchar('review_status', { length: 50 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
}, (table) => {
  return {
    idxUserCustomMetricsReview: index('idx_user_custom_metrics_review').on(table.sourceType, table.reviewStatus),
  };
});

// User Chronic Conditions table
export const userChronicConditions = pgTable('user_chronic_conditions', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  conditionName: varchar('condition_name', { length: 200 }).notNull(),
  status: varchar('status', { length: 20 }).notNull(), // Active, In Remission
  createdAt: timestamp('created_at').defaultNow(),
});

// User Allergies table
export const userAllergies = pgTable('user_allergies', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  allergyType: varchar('allergy_type', { length: 40 }).notNull(), // food, medication, environmental, intolerance
  allergenName: varchar('allergen_name', { length: 200 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  uploads: many(uploads),
  metrics: many(metrics),
  questionnaireResponses: many(questionnaireResponses),
  aiOutputsLog: many(aiOutputsLog),
  dailyPlans: many(dailyPlans),
  imagingStudies: many(imagingStudies),
  userCustomMetrics: many(userCustomMetrics),
  chronicConditions: many(userChronicConditions),
  allergies: many(userAllergies),
}));

export const healthSystemsRelations = relations(healthSystems, ({ many }) => ({
  metrics: many(metrics),
  aiOutputsLog: many(aiOutputsLog),
  imagingStudies: many(imagingStudies),
  userCustomMetrics: many(userCustomMetrics),
}));

export const uploadsRelations = relations(uploads, ({ one, many }) => ({
  user: one(users, {
    fields: [uploads.userId],
    references: [users.id],
  }),
  metrics: many(metrics),
  imagingStudies: many(imagingStudies),
}));

export const metricsRelations = relations(metrics, ({ one }) => ({
  user: one(users, {
    fields: [metrics.userId],
    references: [users.id],
  }),
  upload: one(uploads, {
    fields: [metrics.uploadId],
    references: [uploads.id],
  }),
  healthSystem: one(healthSystems, {
    fields: [metrics.systemId],
    references: [healthSystems.id],
  }),
}));

export const questionnaireResponsesRelations = relations(questionnaireResponses, ({ one }) => ({
  user: one(users, {
    fields: [questionnaireResponses.userId],
    references: [users.id],
  }),
}));

export const aiOutputsLogRelations = relations(aiOutputsLog, ({ one }) => ({
  user: one(users, {
    fields: [aiOutputsLog.userId],
    references: [users.id],
  }),
  healthSystem: one(healthSystems, {
    fields: [aiOutputsLog.systemId],
    references: [healthSystems.id],
  }),
}));

export const dailyPlansRelations = relations(dailyPlans, ({ one }) => ({
  user: one(users, {
    fields: [dailyPlans.userId],
    references: [users.id],
  }),
}));

export const imagingStudiesRelations = relations(imagingStudies, ({ one }) => ({
  user: one(users, {
    fields: [imagingStudies.userId],
    references: [users.id],
  }),
  upload: one(uploads, {
    fields: [imagingStudies.uploadId],
    references: [uploads.id],
  }),
  healthSystem: one(healthSystems, {
    fields: [imagingStudies.linkedSystemId],
    references: [healthSystems.id],
  }),
}));

export const userCustomMetricsRelations = relations(userCustomMetrics, ({ one }) => ({
  user: one(users, {
    fields: [userCustomMetrics.userId],
    references: [users.id],
  }),
  healthSystem: one(healthSystems, {
    fields: [userCustomMetrics.systemId],
    references: [healthSystems.id],
  }),
}));

export const userChronicConditionsRelations = relations(userChronicConditions, ({ one }) => ({
  user: one(users, {
    fields: [userChronicConditions.userId],
    references: [users.id],
  }),
}));

export const userAllergiesRelations = relations(userAllergies, ({ one }) => ({
  user: one(users, {
    fields: [userAllergies.userId],
    references: [users.id],
  }),
}));